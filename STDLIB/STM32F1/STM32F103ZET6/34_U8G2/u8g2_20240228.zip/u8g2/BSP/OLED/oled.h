#ifndef _OLED__H_
#define _OLED__H_

#include "u8g2.h"

void u8g2_Init(u8g2_t *u8g2);

#endif


